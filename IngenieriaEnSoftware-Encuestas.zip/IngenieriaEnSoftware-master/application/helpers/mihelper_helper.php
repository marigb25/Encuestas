<?php
	function getNombre(){
		return "<h1>Alfonso6z 8======D</h1>";
	}
?>